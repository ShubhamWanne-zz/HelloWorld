package com.home.Embedable;

public enum Job {
	CLERK,SALESMAN,MANAGER,ANALYST,PRESIDENT;
}
