package com.home.HibernateApp;

import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.home.Embedable.Address;
import com.home.Embedable.Job;
import com.home.Embedable.UserID;
import com.home.Entity.Person;
import com.home.Entity.Vehicle;

/**
 * Hello world!
 *
 */
public class App 
{
	private SessionFactory session_factory;
	static Logger logger = Logger.getLogger(App.class);
	static{
		PropertyConfigurator.configure("log4j.properties");
	}
	private void _initSession(){
		session_factory = new Configuration().configure().buildSessionFactory();
		if(session_factory!=null)
			logger.info("Sesssion factory created successfully ");
		else 
			logger.error("Unable to create Session factory"); 
	}
	private void _closeSession(){
		session_factory.close();
	}
	public void insertData(){
		Person person = new Person(
									new UserID("USERNAME", "PASSWORD"),
									"NAME", 
									Job.ANALYST, 
									2345, 
									new Date(), 
									12345, 
									1234, 
									1234
								);
		person.getListOfAddresses().add(new Address("Parsodi", 440021));
		person.getListOfAddresses().add(new Address("Ayodhya Nagar",440024));
		
		Vehicle vehicle =  new Vehicle();
		vehicle.setVehicle_name("Bajaj Pulsar 180");
		
		Session session=null;
		try {
			session = session_factory.openSession();
			session.beginTransaction();
			logger.info("Transaction started");
			session.save(person);
			session.save(vehicle);
			System.out.println(person);
			session.getTransaction().commit();
			logger.info("Transaction commited");
			}catch(Exception e){
				if(session!=null) {
					logger.error("Transaction rollbacked");
					session.getTransaction().rollback();
				}else {
					logger.error("Session couldn't be created !");
				}
			}
	}
	public Person getData(int empno){
		Session session=null;
		Person person=null;
		try {
		session = session_factory.openSession();
		session.beginTransaction();
		logger.info("Transaction started");
		person = session.get(Person.class, empno);
		session.getTransaction().commit();
		logger.info("Transaction commited");
		}catch(Exception e){
			if(session!=null) {
				logger.error("Transaction rollbacked");
				session.getTransaction().rollback();
			}else
				logger.error("Session couldn't be created !");
			
		}
		return person;
	}
    public static void main( String[] args ){
    	App application = new App();
    	try {
    	application._initSession();
    	application.insertData();
    	}catch(Exception e) {
    		e.printStackTrace();
    	}if(application.session_factory!=null)
    		application._closeSession();
    }
}
