package com.home.Entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import com.home.Embedable.Address;
import com.home.Embedable.Job;
import com.home.Embedable.UserID;

/*
 * Simple POJO class (Plain Old Java Object)
 */
@Entity
public class Person {
	@EmbeddedId
	private UserID user_id;
	private String ename;
	private Job job;
	private int mgr;
	@Temporal(TemporalType.DATE)
	private Date hiredate;
	private int sal;
	private int comm;
	private int deptno;
	@ElementCollection
	@JoinTable(name="USER_ADDRESS"
			/*
			 * To customize the foreign key notation which is by default table_instanceName
			 * e.g. Person_password, Person_user_name
			 * 
			 * joinColumns = @JoinColumn(name = "USER_ID")
			 * 
			 */
	)
	@GenericGenerator(name = "hilo-gen", strategy = "hilo")
	@CollectionId(columns = { @Column(name = "ADDRESS_ID") }, generator = "hilo-gen", type = @Type(type = "int"))
	Collection<Address> listOfAddresses = new ArrayList<Address>();
	
	public void setListOfAddresses(Collection<Address> listOfAddresses) {
		this.listOfAddresses = listOfAddresses;
	}

	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public Person(UserID user_id, String ename, Job job, int mgr, Date hiredate, int sal, int comm, int deptno) {
		super();
		this.user_id = user_id;
		this.ename = ename;
		this.job = job;
		this.mgr = mgr;
		this.hiredate = hiredate;
		this.sal = sal;
		this.comm = comm;
		this.deptno = deptno;
	}

	public UserID getUser_id() {
		return user_id;
	}

	public void setUser_id(UserID user_id) {
		this.user_id = user_id;
	}
	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public int getMgr() {
		return mgr;
	}

	public void setMgr(int mgr) {
		this.mgr = mgr;
	}

	@Temporal(TemporalType.DATE)
	public Date getHiredate() {
		return hiredate;
	}

	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public int getComm() {
		return comm;
	}

	public void setComm(int comm) {
		this.comm = comm;
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public Collection<Address> getListOfAddresses() {
		return listOfAddresses;
	}
	
}
